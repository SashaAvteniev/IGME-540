#include <iostream>
#include "Game.h"
#include "Graphics.h"
#include "Vertex.h"
#include "Input.h"
#include "PathHelpers.h"
#include "Window.h"
#include "Mesh.h"
#include "BufferStructs.h"
#include "GameEntity.h"

#include <DirectXMath.h>
#include<vector>
// Needed for a helper function to load pre-compiled shader files
#pragma comment(lib, "d3dcompiler.lib")
#include <d3dcompiler.h>

// This code assumes files are in "ImGui" subfolder!
// Adjust as necessary for your own folder structure and project setup
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_dx11.h"
#include "ImGui/imgui_impl_win32.h"

// For the DirectX Math library
using namespace DirectX;

// --------------------------------------------------------
// The constructor is called after the window and graphics API
// are initialized but before the game loop begins
// --------------------------------------------------------
Game::Game()
{
	// Helper methods for loading shaders, creating some basic
	// geometry to draw and some simple camera matrices.
	//  - You'll be expanding and/or replacing these later
	LoadShaders();
	CreateGeometry();

	// Set initial graphics API state
	//  - These settings persist until we change them
	//  - Some of these, like the primitive topology & input layout, probably won't change
	//  - Others, like setting shaders, will need to be moved elsewhere later
	{
		// Tell the input assembler (IA) stage of the pipeline what kind of
		// geometric primitives (points, lines or triangles) we want to draw.  
		// Essentially: "What kind of shape should the GPU draw with our vertices?"
		Graphics::Context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

		// Ensure the pipeline knows how to interpret all the numbers stored in
		// the vertex buffer. For this course, all of your vertices will probably
		// have the same layout, so we can just set this once at startup.
		Graphics::Context->IASetInputLayout(inputLayout.Get());

		// Set the active vertex and pixel shaders
		//  - Once you start applying different shaders to different objects,
		//    these calls will need to happen multiple times per frame
		Graphics::Context->VSSetShader(vertexShader.Get(), 0, 0);
		Graphics::Context->PSSetShader(pixelShader.Get(), 0, 0);

		//Inityialize ImGUi and backends
		IMGUI_CHECKVERSION();
		ImGui::CreateContext();
		ImGui_ImplWin32_Init(Window::Handle());
		ImGui_ImplDX11_Init(Graphics::Device.Get(), Graphics::Context.Get());

		//Style
		ImGui::StyleColorsDark();
	}

	//Setting constant buffer
	// Describe the constant buffer
	D3D11_BUFFER_DESC cbDesc = {}; // Sets struct to all zeros
	cbDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	unsigned int size = sizeof(VertexShaderData);
	size = ((size + 15) / 16) * 16;
	cbDesc.ByteWidth = size;
	cbDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	cbDesc.Usage = D3D11_USAGE_DYNAMIC;
	Graphics::Device->CreateBuffer(&cbDesc, 0, &constBuffer);

	Graphics::Context->VSSetConstantBuffers(
		0, // Which slot (register) to bind the buffer to?
		1, // How many are we setting right now?
		&constBuffer);


}


// --------------------------------------------------------
// Clean up memory or objects created by this class
// 
// Note: Using smart pointers means there probably won't
//       be much to manually clean up here!
// --------------------------------------------------------
Game::~Game()
{
	// Cleaning up ImGui
	ImGui_ImplDX11_Shutdown();
	ImGui_ImplWin32_Shutdown();
	ImGui::DestroyContext();
}


// --------------------------------------------------------
// Loads shaders from compiled shader object (.cso) files
// and also created the Input Layout that describes our 
// vertex data to the rendering pipeline. 
// - Input Layout creation is done here because it must 
//    be verified against vertex shader byte code
// - We'll have that byte code already loaded below
// --------------------------------------------------------
void Game::LoadShaders()
{
	// BLOBs (or Binary Large OBjects) for reading raw data from external files
	// - This is a simplified way of handling big chunks of external data
	// - Literally just a big array of bytes read from a file
	ID3DBlob* pixelShaderBlob;
	ID3DBlob* vertexShaderBlob;

	// Loading shaders
	//  - Visual Studio will compile our shaders at build time
	//  - They are saved as .cso (Compiled Shader Object) files
	//  - We need to load them when the application starts
	{
		// Read our compiled shader code files into blobs
		// - Essentially just "open the file and plop its contents here"
		// - Uses the custom FixPath() helper from Helpers.h to ensure relative paths
		// - Note the "L" before the string - this tells the compiler the string uses wide characters
		D3DReadFileToBlob(FixPath(L"PixelShader.cso").c_str(), &pixelShaderBlob);
		D3DReadFileToBlob(FixPath(L"VertexShader.cso").c_str(), &vertexShaderBlob);

		// Create the actual Direct3D shaders on the GPU
		Graphics::Device->CreatePixelShader(
			pixelShaderBlob->GetBufferPointer(),	// Pointer to blob's contents
			pixelShaderBlob->GetBufferSize(),		// How big is that data?
			0,										// No classes in this shader
			pixelShader.GetAddressOf());			// Address of the ID3D11PixelShader pointer

		Graphics::Device->CreateVertexShader(
			vertexShaderBlob->GetBufferPointer(),	// Get a pointer to the blob's contents
			vertexShaderBlob->GetBufferSize(),		// How big is that data?
			0,										// No classes in this shader
			vertexShader.GetAddressOf());			// The address of the ID3D11VertexShader pointer
	}

	// Create an input layout 
	//  - This describes the layout of data sent to a vertex shader
	//  - In other words, it describes how to interpret data (numbers) in a vertex buffer
	//  - Doing this NOW because it requires a vertex shader's byte code to verify against!
	//  - Luckily, we already have that loaded (the vertex shader blob above)
	{
		D3D11_INPUT_ELEMENT_DESC inputElements[2] = {};

		// Set up the first element - a position, which is 3 float values
		inputElements[0].Format = DXGI_FORMAT_R32G32B32_FLOAT;				// Most formats are described as color channels; really it just means "Three 32-bit floats"
		inputElements[0].SemanticName = "POSITION";							// This is "POSITION" - needs to match the semantics in our vertex shader input!
		inputElements[0].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;	// How far into the vertex is this?  Assume it's after the previous element

		// Set up the second element - a color, which is 4 more float values
		inputElements[1].Format = DXGI_FORMAT_R32G32B32A32_FLOAT;			// 4x 32-bit floats
		inputElements[1].SemanticName = "COLOR";							// Match our vertex shader input!
		inputElements[1].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;	// After the previous element

		// Create the input layout, verifying our description against actual shader code
		Graphics::Device->CreateInputLayout(
			inputElements,							// An array of descriptions
			2,										// How many elements in that array?
			vertexShaderBlob->GetBufferPointer(),	// Pointer to the code of a shader that uses this layout
			vertexShaderBlob->GetBufferSize(),		// Size of the shader code that uses this layout
			inputLayout.GetAddressOf());			// Address of the resulting ID3D11InputLayout pointer
	}
}


// --------------------------------------------------------
// Creates the geometry we're going to draw
// --------------------------------------------------------
void Game::CreateGeometry()
{
	//Base Triangle
	{
		// Create some temporary variables to represent colors
		// - Not necessary, just makes things more readable
		XMFLOAT4 red = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
		XMFLOAT4 green = XMFLOAT4(0.0f, 1.0f, 0.0f, 1.0f);
		XMFLOAT4 blue = XMFLOAT4(0.0f, 0.0f, 1.0f, 1.0f);

		// Set up the vertices of the triangle we would like to draw
		// - We're going to copy this array, exactly as it exists in CPU memory
		//    over to a Direct3D-controlled data structure on the GPU (the vertex buffer)
		// - Note: Since we don't have a camera or really any concept of
		//    a "3d world" yet, we're simply describing positions within the
		//    bounds of how the rasterizer sees our screen: [-1 to +1] on X and Y
		// - This means (0,0) is at the very center of the screen.
		// - These are known as "Normalized Device Coordinates" or "Homogeneous 
		//    Screen Coords", which are ways to describe a position without
		//    knowing the exact size (in pixels) of the image/window/etc.  
		// - Long story short: Resizing the window also resizes the triangle,
		//    since we're describing the triangle in terms of the window itself
		Vertex vertices[] =
		{
			{ XMFLOAT3(+0.0f, +0.5f, +0.0f), red },
			{ XMFLOAT3(+0.5f, -0.5f, +0.0f), blue },
			{ XMFLOAT3(-0.5f, -0.5f, +0.0f), green },
		};

		// Set up indices, which tell us which vertices to use and in which order
		// - This is redundant for just 3 vertices, but will be more useful later
		// - Indices are technically not required if the vertices are in the buffer 
		//    in the correct order and each one will be used exactly once
		// - But just to see how it's done...
		unsigned int indices[] = { 0, 1, 2 };

		baseTriangle = std::make_shared<Mesh>(vertices, (int)(sizeof(vertices)/sizeof(vertices[0])), 
											  indices, (int)(sizeof(indices) / sizeof(indices[0])));
		GameEntity triangle = GameEntity(*baseTriangle);
		entities.push_back(triangle);
	}
	
	//Rect
	{
		XMFLOAT4 squareColor = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);

		Vertex squareVerteces[] = {
			{ XMFLOAT3(.7f,.7f,.0f), squareColor }, // 0
			{ XMFLOAT3(.7f,.8f,.0f), squareColor }, // 1
			{ XMFLOAT3(.8f,.8f,.0f), squareColor }, // 2
			{ XMFLOAT3(.8f,.7f,.0f), squareColor }  // 3


		};

		unsigned int squareIndices[] = { 0,1,2,
										 0,2,3};

		squareTest = std::make_shared<Mesh>(squareVerteces, (int)(sizeof(squareVerteces)/sizeof(squareVerteces[0])), 
											squareIndices, (int)(sizeof(squareIndices)/sizeof(squareIndices[0])));
		GameEntity squareOne = GameEntity(*squareTest);
		entities.push_back(squareOne);
		GameEntity squareTwo = GameEntity(*squareTest);
		entities.push_back(squareTwo);
	}

	//WeirdAngle
	{
		XMFLOAT4 weirdColor = XMFLOAT4(0.0f, 0.0f, .7f, 1.0f);

		Vertex weirdVerteces[] = {
			{ XMFLOAT3(-.7f,-.7f,.0f), weirdColor }, // 0
			{ XMFLOAT3(-.7f,-.8f,.0f), weirdColor }, // 1
			{ XMFLOAT3(-.8f,-.8f,.0f), weirdColor }, // 2
			{ XMFLOAT3(-.8f,-.7f,.0f), weirdColor }  // 3


		};

		unsigned int weirdIndices[] = { 0,1,2,
										 1,2,3 };

		weirdTest = std::make_shared<Mesh>(weirdVerteces, (int)(sizeof(weirdVerteces) / sizeof(weirdVerteces[0])), 
											weirdIndices, (int)(sizeof(weirdIndices) / sizeof(weirdIndices[0])));

		GameEntity weirdOne = GameEntity(*weirdTest);
		entities.push_back(weirdOne);
		GameEntity weirdTwo = GameEntity(*weirdTest);
		entities.push_back(weirdTwo);

	}

}


// --------------------------------------------------------
// Handle resizing to match the new window size
//  - Eventually, we'll want to update our 3D camera
// --------------------------------------------------------
void Game::OnResize()
{
	
}

void ImGUIUpdate(float deltaTime)
{

	// Feed fresh data to ImGui
	ImGuiIO& io = ImGui::GetIO();
	io.DeltaTime = deltaTime;
	io.DisplaySize.x = (float)Window::Width();
	io.DisplaySize.y = (float)Window::Height();
	// Reset the frame
	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();
	// Determine new input capture
	Input::SetKeyboardCapture(io.WantCaptureKeyboard);
	Input::SetMouseCapture(io.WantCaptureMouse);
	// Show the demo window
	//ImGui::ShowDemoWindow();
}

void Game::BuildUI() {
	ImGui::Begin("Starter Window");

	ImGui::Text("App Details");
	float framerate = ImGui::GetIO().Framerate;
	ImGui::Text("Frame rate: %f fps", framerate);
	ImGui::Text("Window Client Size: %dx%d", Window::Width(), Window::Height());
	ImGui::ColorEdit4("Background Color", &backgroundColor[0]);

	if (ImGui::Button("Show Demo Window")) {
		showDefault = !showDefault;
	}
	if (showDefault) {
		ImGui::ShowDemoWindow();
	}
	if(ImGui::CollapsingHeader("Rest of work")) {
		ImGui::InputText("Input", starting, IM_ARRAYSIZE(starting));
		ImGui::SliderFloat3("Position", positionVector, -10.f, 10.0f);
	}
	if (ImGui::CollapsingHeader("ConstBuffer")) {
		ImGui::ColorEdit4("Color Shift", &colorChange[0]);
	}
	if (ImGui::CollapsingHeader("Entities")) {
		if (ImGui::CollapsingHeader("Entity 0")) {
			
			ImGui::DragFloat3("Position##0", &entities[0].GetTransform()->position.x);
			ImGui::DragFloat3("Rotation:Radians##0", &entities[0].GetTransform()->rotation.x);
			ImGui::DragFloat3("Scale##0", &entities[0].GetTransform()->scale.x);
		}
		if (ImGui::CollapsingHeader("Entity 1")) {

			ImGui::DragFloat3("Position##1", &entities[1].GetTransform()->position.x);
			ImGui::DragFloat3("Rotation:Radians##1", &entities[1].GetTransform()->rotation.x);
			ImGui::DragFloat3("Scale##1", &entities[1].GetTransform()->scale.x);
		}
		if (ImGui::CollapsingHeader("Entity 2")) {

			ImGui::DragFloat3("Position##2", &entities[2].GetTransform()->position.x);
			ImGui::DragFloat3("Rotation:Radians##2", &entities[2].GetTransform()->rotation.x);
			ImGui::DragFloat3("Scale##2", &entities[2].GetTransform()->scale.x);
		}
		if (ImGui::CollapsingHeader("Entity 3")) {

			ImGui::DragFloat3("Position##3", &entities[3].GetTransform()->position.x);
			ImGui::DragFloat3("Rotation:Radians##3", &entities[3].GetTransform()->rotation.x);
			ImGui::DragFloat3("Scale##3", &entities[3].GetTransform()->scale.x);
		}
		if (ImGui::CollapsingHeader("Entity 4")) {

			ImGui::DragFloat3("Position##4", &entities[4].GetTransform()->position.x);
			ImGui::DragFloat3("Rotation:Radians##4", &entities[4].GetTransform()->rotation.x);
			ImGui::DragFloat3("Scale##4", &entities[4].GetTransform()->scale.x);
		}
	}
	if (ImGui::CollapsingHeader("Meshes")) {
		if (ImGui::CollapsingHeader("Mesh: Triangle")) {
			ImGui::Text("Triangles: %d", baseTriangle->GetIndexCount()/3);
			ImGui::Text("Vertices:  %d", baseTriangle->GetVertexCount());
			ImGui::Text("Indices:   %d", baseTriangle->GetIndexCount());
		}
		if (ImGui::CollapsingHeader("Mesh: Rectangle")) {
			ImGui::Text("Triangles: %d",  squareTest->GetIndexCount() / 3);
			ImGui::Text("Vertices:  %d", squareTest->GetVertexCount());
			ImGui::Text("Indices:   %d", squareTest->GetIndexCount());
		}
		if (ImGui::CollapsingHeader("Mesh: Weird Shape")) {
			ImGui::Text("Triangles: %d", weirdTest->GetIndexCount() / 3);
			ImGui::Text("Vertices:  %d", weirdTest->GetVertexCount());
			ImGui::Text("Indices:   %d", weirdTest->GetIndexCount());
		}
	}
	ImGui:: End();
	

}
// --------------------------------------------------------
// Update your game here - user input, move objects, AI, etc.
// --------------------------------------------------------
void Game::Update(float deltaTime, float totalTime)
{
	ImGUIUpdate(deltaTime);
	BuildUI();
	// Example input checking: Quit if the escape key is pressed
	if (Input::KeyDown(VK_ESCAPE))
		Window::Quit();

	//Moving objects
	entities[0].GetTransform()->MoveAbsolute(.1f * deltaTime, 0, 0);
	entities[1].GetTransform()->Rotate(0, 0, .1f *deltaTime);
	entities[2].GetTransform()->MoveAbsolute(0, .1f *deltaTime * sin(1 * totalTime), 0);
	entities[3].GetTransform()->MoveAbsolute(.1f *deltaTime,0,0);
	entities[4].GetTransform()->Scale(1 + deltaTime * sin(1 * totalTime), 1 + deltaTime * sin(1 * totalTime), 1);

}


// --------------------------------------------------------
// Clear the screen, redraw everything, present to the user
// --------------------------------------------------------
void Game::Draw(float deltaTime, float totalTime)
{
	// Frame START
	// - These things should happen ONCE PER FRAME
	// - At the beginning of Game::Draw() before drawing *anything*
	{
		// Clear the back buffer (erase what's on screen) and depth buffer
		const float color[4] = { backgroundColor[0], backgroundColor[1], backgroundColor[2], backgroundColor[3] };
		Graphics::Context->ClearRenderTargetView(Graphics::BackBufferRTV.Get(),	color);
		Graphics::Context->ClearDepthStencilView(Graphics::DepthBufferDSV.Get(), D3D11_CLEAR_DEPTH, 1.0f, 0);
	}

	//Replace with Mesh Draw Calls
	///
	///
	/// 
	/// 
	/// 
	/// 
	/// 
	
	for (int i = 0; i < entities.size(); i++) {
		vsData.colorTint = XMFLOAT4(colorChange[0], colorChange[1], colorChange[2], colorChange[3]);
		vsData.world = entities[i].objectTransform.world;
		D3D11_MAPPED_SUBRESOURCE mappedBuffer = {};
		Graphics::Context->Map(constBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedBuffer);
		memcpy(mappedBuffer.pData, &vsData, sizeof(vsData));
		Graphics::Context->Unmap(constBuffer, 0);

		entities[i].GetMesh()->Draw();
	}


	//Old



	// Frame END
	// - These should happen exactly ONCE PER FRAME
	// - At the very end of the frame (after drawing *everything*)
	{
		// Present at the end of the frame
		bool vsync = Graphics::VsyncState();
		ImGui::Render(); // Turns this frame’s UI into renderable triangles
		ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData()); // Draws it to the screen
		Graphics::SwapChain->Present(
			vsync ? 1 : 0,
			vsync ? 0 : DXGI_PRESENT_ALLOW_TEARING);

		// Re-bind back buffer and depth buffer after presenting
		Graphics::Context->OMSetRenderTargets(
			1,
			Graphics::BackBufferRTV.GetAddressOf(),
			Graphics::DepthBufferDSV.Get());
	}
}




